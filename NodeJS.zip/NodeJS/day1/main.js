// module 스크립트 포함(#include).
let util = require('./module');

console.log(typeof util);

console.log( util.addNumber(10,20));
console.log( util.substract(30,20));