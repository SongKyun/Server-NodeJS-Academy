// 문자형 String.
//console.log('hello world');
//console.log("hello world");
//console.log(`hello world`);

// 자바스크립트는 모듈링이 안된다.
// 그런데 NodeJS는 모듈링이 가능하다.
//Export - Import. 임포트 키워드를 사용해서 외부 파일을 가져온다.
// h / cpp.

// Ctrl + Alt + Arrow
// 변수
// JS-Javascript / TS-Type Script
// 변수는 var 키워드로 선언한다.
// let 변수 선언 / const 상수 선언
// 스코프(범위, Scope, Range) c -> { }, JS -> 함수.
// class는 없다.
// JS는 객체지향 언어이지만, 우리가 알던 CLASS는 없다.

//const number = "abc";
 //let age = 30;

// 일단 const로 선언하고, 변경이 필요하면 let으로 바꾼다.

//if (age == 30) {
    // const test = 30;
//}

//test = 50;
//console.log(test);

//let numberA = 0.1;
//let numberB = 0.2;
//let numberC = 0.3;
//
//if ((numberA + numberB) == numberC) {
//    console.log('같음');
//} else {
//    console.log('다름');
//}

// 자동 형변환을 해준다.
// == != / === !==
//if (1 !='1') {
//    console.log("같음");
//} else {
//    console.log("다름");
//}

// Array = 객체 = 해시 테이블
let array = [1, 2, 3, 4, 5];
console.log(array[1], array[3]);
let arrayStyle = {
    '0' : 1,
    '1' : 2,
    '2' : 3
}

// 배열의 장점?

// Object 객체
// -> Key / Value의 쌍으로 이루어진 데이터.
// 해시 테이블
//let object = {
//    name : 'song',
//    age : 38,    
//}

// 같은 정의
//let object = {
//        'name' : 'song',
//      'age' : 38,
//      test : function(){
//        console.log('test function is called');
//      }    
//    }
//    console.test();
// JSON - JavaScript 자바 스크립트 객체 문법을 보라.

//console.log(object['name'], object['age']);
//console.log(object.name, object.age);

//console.log(typeof(1),typeof)
