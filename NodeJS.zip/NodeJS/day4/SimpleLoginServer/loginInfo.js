// 로그인 정보.
module.exports = {
    userid : 'Songkyun',
    password : '1234'
}