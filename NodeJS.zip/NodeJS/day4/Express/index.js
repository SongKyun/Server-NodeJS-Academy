// 모듈 가져오기.
const server = require('./server');

// 서버 시작.
server.start();